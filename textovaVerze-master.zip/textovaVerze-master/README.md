# textovaVerze
